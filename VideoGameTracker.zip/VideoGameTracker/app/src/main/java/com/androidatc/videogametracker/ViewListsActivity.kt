package com.androidatc.videogametracker

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ViewListsActivity: AppCompatActivity() {
    // declaring variables
    private lateinit var listsTextView: TextView
    private lateinit var backToHomeButton: Button
    private lateinit var preferencesButton: Button
    private lateinit var viewWantToPlayButton: Button
    private lateinit var viewHavePlayedButton: Button
    private lateinit var clearListsButton: Button

    private var wantToPlayList: MutableList<String>? = null
    private var havePlayedList: MutableList<String>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_lists)

        // initializing UI elements
        listsTextView = findViewById(R.id.listTextViews)
        backToHomeButton = findViewById(R.id.backToHomeButton)
        preferencesButton = findViewById(R.id.preferencesButton)
        viewWantToPlayButton = findViewById(R.id.viewWantToPlay)
        viewHavePlayedButton = findViewById(R.id.viewHavePlayed)
        clearListsButton = findViewById(R.id.clearListsButton)

        // Retrieve lists from SharedPreferences
        val preferences = getSharedPreferences("GameLists", Context.MODE_PRIVATE)
        wantToPlayList = preferences.getString("WantToPlayGamesList", null)?.split("\n")?.toMutableList()
        havePlayedList = preferences.getString("HavePlayedGamesList", null)?.split("\n")?.toMutableList()

        // Setting click listener
        preferencesButton.setOnClickListener { goToPreferencesActivity() }
        backToHomeButton.setOnClickListener { goBackHome() }
        viewWantToPlayButton.setOnClickListener { displayListWithHeader("Want To Play Games:", wantToPlayList) }
        viewHavePlayedButton.setOnClickListener { displayListWithHeader("Have Played Games:", havePlayedList) }

        clearListsButton.setOnClickListener { clearLists() }
    }

    // navigating to preferences
    private fun goToPreferencesActivity() {
        val intent = Intent(this, PreferencesActivity::class.java)
        startActivity(intent)
    }

    // navigating back to the main activity
    private fun goBackHome() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    private fun displayListWithHeader(header: String, list:List<String>?) {
        // Displaying a header
        listsTextView.text = if (list != null && list.isNotEmpty()) {
            "$header${list.joinToString("\n")}"
        } else {
            "$header\nNo games in this list"
        }
    }

    private fun clearLists() {
        // clearing the lists
        wantToPlayList?.clear()
        havePlayedList?.clear()

        // saving empty lists
        val preferences = getSharedPreferences("GameLists", Context.MODE_PRIVATE)
        val editor = preferences.edit()
        editor.putString("WantToPlayGamesList", "")
        editor.putString("HavePlayedGamesList", "")
        editor.apply()

        // updating the UI
        listsTextView.text = "You have cleared both lists. They are now both empty."

        listsTextView.movementMethod = ScrollingMovementMethod()

    }
}
