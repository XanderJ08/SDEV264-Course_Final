package com.androidatc.videogametracker

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PreferencesActivity: AppCompatActivity() {
    // declaring variables
    private lateinit var backButton: Button
    private lateinit var editHavePlayedListButton: Button
    private lateinit var editWantToPlayListButton: Button
    private lateinit var submitButton: Button
    private lateinit var gameListEditText: EditText
    private lateinit var listNameText: TextView
    private var isWantToPlayList: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preferences)

        // initializing UI elements
        backButton = findViewById(R.id.backButton)
        editHavePlayedListButton = findViewById(R.id.editHavePlayedListButton)
        editWantToPlayListButton = findViewById(R.id.editWantToPlayListButton)
        submitButton = findViewById(R.id.submitButton)
        gameListEditText = findViewById(R.id.gameListEditText)
        listNameText = findViewById(R.id.listNameText)

        // setting click listener
        backButton.setOnClickListener { goBackToViewListsActivity() }
        editHavePlayedListButton.setOnClickListener {
            loadHavePlayedGamesList()
            isWantToPlayList = false
            listNameText.text = "Have Played Games List"
        }
        editWantToPlayListButton.setOnClickListener {
            loadWantToPlayGamesList()
            isWantToPlayList = true
            listNameText.text = "Want To Play Games List"
        }
        submitButton.setOnClickListener { submitListChanges() }

    }

    private fun loadHavePlayedGamesList() {
        // retrieving the list from shared preferences
        val preferences = getSharedPreferences("GameLists", Context.MODE_PRIVATE)
        val gameListKey = "HavePlayedGamesList"
        val gameList = preferences.getString(gameListKey, null)

        // setting the list in edit text
        gameListEditText.setText(gameList)

        // updating the isWantToPlayList variable
        isWantToPlayList = false
    }

    private fun loadWantToPlayGamesList() {
        // retrieving the list from shared preferences
        val preferences = getSharedPreferences("GameLists", Context.MODE_PRIVATE)
        val gameListKey = "WantToPlayGamesList"
        val gameList = preferences.getString(gameListKey, null)

        // setting the list in edit text
        gameListEditText.setText(gameList)
    }

    private fun submitListChanges() {
        // getting the edited list
        val editedGameList = gameListEditText.text.toString()

        // saving the updated list
        val preferences = getSharedPreferences("GameLists", Context.MODE_PRIVATE)
        val gameListKey = if (isWantToPlayList) "WantToPlayGamesList" else "HavePlayedGamesList"
        val editor = preferences.edit()
        editor.putString(gameListKey, editedGameList)
        editor.apply()

        // Go back to ViewListsActivity
        goBackToViewListsActivity()
    }

    private fun goBackToViewListsActivity() {
        val intent = Intent(this, ViewListsActivity::class.java)
        startActivity(intent)
    }
}


