package com.androidatc.videogametracker

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class AdditionalQuestionsActivity: AppCompatActivity() {
    private lateinit var question1EditText: EditText
    private lateinit var question2EditText: EditText
    private lateinit var submitButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_additional_questions)

        // initializing UI elements
        question1EditText = findViewById(R.id.question1EditText)
        question2EditText = findViewById(R.id.question2EditText)
        submitButton = findViewById(R.id.submitButton)

        // Retrieving questions from Intent
        val question1 = intent.getStringExtra("QUESTION_1")
        val question2 = intent.getStringExtra("QUESTION_2")

        // Setting the questions as hints
        question1EditText.hint = question1
        question2EditText.hint = question2

        // setting click listener
        submitButton.setOnClickListener { submitAnswers() }
    }

    private fun submitAnswers() {
        val answer1 = question1EditText.text.toString()
        val answer2 = question2EditText.text.toString()

        // retrieving the list from shared preferences
        val preferences = getSharedPreferences("GameLists", Context.MODE_PRIVATE)
        var wantToPlayList = preferences.getString("WantToPlayGamesList", null)?.split("\n")?.toMutableList()
        var havePlayedList = preferences.getString("HavePlayedGamesList", null)?.split("\n")?.toMutableList()

        // ensuring the lists are not null
        if (wantToPlayList == null) {
            wantToPlayList = mutableListOf()
        }
        if (havePlayedList == null) {
            havePlayedList = mutableListOf()
        }

        // updating the answers in the list based on the selection
        if (question1EditText.hint == "Where can you buy the game?") {
            wantToPlayList?.let { updateListWithAnswers(it, answer1, answer2) }
        } else if (question1EditText.hint == "Personal rating (0 to 5 stars)") {
            havePlayedList?.let { updateListWithAnswers(it, answer1, answer2) }
        }


        // saving the lists
        val editor = preferences.edit()
        editor.putString("WantToPlayGamesList", wantToPlayList?.joinToString("\n"))
        editor.putString("HavePlayedGamesList", havePlayedList?.joinToString("\n"))
        editor.apply()

        // Returning to Previous Activity
        goToViewListsActivity()
    }

    private fun updateListWithAnswers(list:MutableList<String>, answer1: String, answer2: String) {
        // making sure one item is in the list
        if (list.isNotEmpty()) {
            // updating the answers into the last item
            val lastGame = list.last()
            if (question1EditText.hint == "Where can you buy the game?") {
                val updatedGame = "$lastGame\nPlace To Buy: $answer1\nPrice: $answer2\n"
                list[list.size - 1] = updatedGame
            }
            if (question1EditText.hint == "Personal rating (0 to 5 stars)") {
                val updatedGame = "$lastGame\nRating (0 to 5 stars): $answer1\nReview (optional): $answer2\n"
                list[list.size - 1] = updatedGame
            }

        }
    }

    private fun goToViewListsActivity() {
        val intent = Intent(this, ViewListsActivity::class.java)
        startActivity(intent)
    }
}