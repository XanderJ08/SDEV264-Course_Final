package com.androidatc.videogametracker

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class HelpActivity: AppCompatActivity() {
    // declaring variables
    private lateinit var closeButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help)

        // initializing UI elements
        closeButton = findViewById(R.id.closeButton)

        // setting click listener
        closeButton.setOnClickListener { closeHelpActivity () }
    }

    private fun closeHelpActivity() {
        finish()
    }
}