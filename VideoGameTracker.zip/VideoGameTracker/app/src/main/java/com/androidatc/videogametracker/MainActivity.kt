package com.androidatc.videogametracker

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {

    // declaring variables
    private lateinit var gameNameEditText: EditText
    private lateinit var gameConsoleEditText: EditText
    private lateinit var gameRatingEditText: EditText
    private lateinit var releaseDateEditText: EditText
    private lateinit var gameDescriptionEditText: EditText
    private lateinit var wantToPlayButton: Button
    private lateinit var havePlayedButton: Button
    private lateinit var viewListsButton: Button

    // creating lists
    private val wantToPlayGamesList: ArrayList<String> = ArrayList()
    private val havePlayedGamesList: ArrayList<String> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // initializing elements
        gameNameEditText = findViewById(R.id.gameName)
        gameConsoleEditText = findViewById(R.id.gameConsole)
        gameRatingEditText = findViewById(R.id.gameRating)
        releaseDateEditText = findViewById(R.id.releaseDate)
        gameDescriptionEditText = findViewById(R.id.gameDescription)
        wantToPlayButton = findViewById(R.id.wantToPlayGames)
        havePlayedButton = findViewById(R.id.havePlayedGames)
        viewListsButton = findViewById(R.id.viewLists)

        // Retrieve Lists from shared Preferences
        val preferences = getSharedPreferences("GameLists", Context.MODE_PRIVATE)
        wantToPlayGamesList.addAll(preferences.getString("WantToPlayGamesList", null)?.split("\n") ?: emptyList())
        havePlayedGamesList.addAll(preferences.getString("HavePlayedGamesList", null)?.split("\n") ?: emptyList())

        // setting click listeners
        wantToPlayButton.setOnClickListener {
            addToGameList()
            launchAdditionalQuestionsActivity("Where can you buy the game?", "What is the price of the game?")
        }
        havePlayedButton.setOnClickListener {
            addToGameList()
            launchAdditionalQuestionsActivity("Personal rating (0 to 5 stars)", "Leave a review (optional)")
        }

        viewListsButton.setOnClickListener { goToViewListsActivity() }

        val helpButton: Button = findViewById(R.id.helpButton)
        helpButton.setOnClickListener { gotoHelpActivity() }
    }

    // add the input details to game list
    private fun addToGameList() {
        val gameName = gameNameEditText.text.toString()
        val gameConsole = gameConsoleEditText.text.toString()
        val gameRating = gameRatingEditText.text.toString()
        val releaseDate = releaseDateEditText.text.toString()
        val gameDescription = gameDescriptionEditText.text.toString()

        // creating game item
        val game =
                "Game Name: $gameName" +
                "\nGame Console: $gameConsole" +
                "\nGame Rating: $gameRating" +
                "\nRelease Date: $releaseDate" +
                "\nGame Description: $gameDescription"

        // setting listeners to add the game to the specific list
        if (wantToPlayButton.isPressed) {
            wantToPlayGamesList.add(game)
        }

        if (havePlayedButton.isPressed) {
            havePlayedGamesList.add(game)
        }

        // Saving the items in Shared Preferences
        val preferences = getSharedPreferences("GameLists", Context.MODE_PRIVATE)
        val editor = preferences.edit()
        editor.putString("WantToPlayGamesList", wantToPlayGamesList.joinToString("\n"))
        editor.putString("HavePlayedGamesList", havePlayedGamesList.joinToString("\n"))
        editor.apply()

        // clearing input fields after adding to the list
        clearInputFields()

        // Creating an intent to pass data
        val intent = Intent(this, ViewListsActivity::class.java)
        startActivity(intent)
    }

    // navigating to help activity
    private fun gotoHelpActivity() {
        val intent = Intent(this, HelpActivity::class.java)
        startActivity(intent)
    }

    // navigating to ViewListsActivity
    private fun goToViewListsActivity() {
        val intent = Intent(this, ViewListsActivity::class.java)
        startActivity(intent)
    }

    // navigating to AdditionalQuestionsActivity
    private fun launchAdditionalQuestionsActivity(question1: String, question2: String) {
        val intent = Intent(this,AdditionalQuestionsActivity::class.java)
        intent.putExtra("QUESTION_1", question1)
        intent.putExtra("QUESTION_2", question2)
        startActivity(intent)
    }

    // allowing the user to clear the input fields
    private fun clearInputFields() {
        gameNameEditText.text.clear()
        gameConsoleEditText.text.clear()
        gameRatingEditText.text.clear()
        releaseDateEditText.text.clear()
        gameDescriptionEditText.text.clear()
    }

}